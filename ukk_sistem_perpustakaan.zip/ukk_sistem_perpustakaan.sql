-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Feb 02, 2025 at 05:08 PM
-- Server version: 8.0.30
-- PHP Version: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ukk_sistem_perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('356a192b7913b04c54574d18c28d46e6395428ab', 'i:2;', 1738341096),
('356a192b7913b04c54574d18c28d46e6395428ab:timer', 'i:1738341096;', 1738341096),
('a17961fa74e9275d529f489537f179c05d50c2f3', 'i:1;', 1738340251),
('a17961fa74e9275d529f489537f179c05d50c2f3:timer', 'i:1738340251;', 1738340251);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_12_17_172205_create_library_tables', 1),
(5, '2024_12_17_172242_add_isadmin_to_users_table', 1),
(6, '2024_12_30_060351_add_status_request_to_transaksi_table', 1),
(7, '2024_12_30_132055_create_notifications_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('H4XWoxFg8sl6pMWeUCs1Lz4IYQUKlvZstRrrTppK', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiam50bURhZkd1WmJLUG00ZXprcVlOQlNzcFQ3d3Y4ZEY0M2U2dzc2biI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9hbmdnb3RhcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjA6e31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTIkTEI5SUR6UC93YWFxbWFIRGM4T3JFLkpRZzJsNGVRMEUzQUhXM3ZIbEc2QlMxWTNnTjd4a3EiO3M6ODoiZmlsYW1lbnQiO2E6MDp7fX0=', 1738342544),
('LA9IQJyLwco34Xfe9jWpYF035dWSCqkMihNuk7MC', 6, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoibUtuTHR1eXZjaXlLZ0o4ZnpnZHdDUEVTOUFZRHJZS2hVSG1TSFNkSiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kaWdpbGliIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjY7fQ==', 1738342938);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_anggota`
--

CREATE TABLE `tbl_anggota` (
  `id_anggota` bigint UNSIGNED NOT NULL,
  `id_jenis_anggota` bigint UNSIGNED NOT NULL,
  `kode_anggota` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_anggota` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telp` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_daftar` date NOT NULL,
  `masa_aktif` date NOT NULL,
  `fa` enum('Y','T') COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_anggota`
--

INSERT INTO `tbl_anggota` (`id_anggota`, `id_jenis_anggota`, `kode_anggota`, `nama_anggota`, `tempat`, `tgl_lahir`, `alamat`, `no_telp`, `email`, `tgl_daftar`, `masa_aktif`, `fa`, `keterangan`, `foto`, `username`, `password`) VALUES
(1, 1, 'A001', 'Axel Pratama', 'Surabaya', '1990-05-12', 'Jl. Raya No. 1', '081234567890', 'admin@gmail.com', '2025-01-19', '2030-01-19', 'Y', 'Administrator perpustakaan', '', 'admin', '$2y$12$LB9IDzP/waaqmaHDc8OrE.JQg2l4eQ0E3AHW3vHlG6BS1Y3gN7xkq'),
(2, 2, 'P001', 'Jane Smith', 'Malang', '1985-08-22', 'Jl. Pustaka No. 2', '081234567891', 'pustakawan@gmail.com', '2025-01-19', '2026-01-19', 'Y', 'Pustakawan utama', '', 'pustakawan', '$2y$12$0mTYiJYE6E506l5BYDF9g.2J2YrVAv50qt1/kye5EW9X3O0Z6QsBa'),
(3, 3, 'S001', 'Budi Santoso', 'Sidoarjo', '2005-02-20', 'Jl. Siswa No. 3', '081234567892', 'budi.santoso@email.com', '2025-01-19', '2026-01-19', 'Y', 'Siswa kelas 12', '', 'budisantoso', '$2y$12$XEFvz9AIUOf8IsI1QSmxYe0KfwToOhtCpfray5OfsA6y6LjQZUqty'),
(4, 4, 'G001', 'Dewi Kusuma', 'Surabaya', '1980-01-15', 'Jl. Guru No. 4', '081234567893', 'dewi.kusuma@email.com', '2025-01-19', '2026-01-19', 'Y', 'Guru matematika', '', 'dewikusuma', '$2y$12$NhlRCEc.C1M9GaL.sjclQ.oSWgzhvkRg/wRvHEYRuwJ4.LvqBiLi.'),
(6, 3, 'S002', 'Novita Herawati Liono ', 'Sidoarjo', '2025-01-19', 'Candi', '081987654321', 'novita@gmail.com', '2025-01-19', '2025-03-20', 'Y', '-', 'images/anggota/01JHZJH4SVY5SG863J6AWBBB19.png', 'novita', '$2y$12$LB9IDzP/waaqmaHDc8OrE.JQg2l4eQ0E3AHW3vHlG6BS1Y3gN7xkq');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ddc`
--

CREATE TABLE `tbl_ddc` (
  `id_ddc` bigint UNSIGNED NOT NULL,
  `id_rak` bigint UNSIGNED NOT NULL,
  `kode_ddc` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ddc` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_ddc`
--

INSERT INTO `tbl_ddc` (`id_ddc`, `id_rak`, `kode_ddc`, `ddc`, `keterangan`) VALUES
(1, 15, '001', 'Pengetahuan Umum', 'Buku tentang pengetahuan umum seperti ensiklopedia, kamus, dan ilmu interdisipliner.'),
(2, 7, '002', 'Buku, Penulisan, dan Perpustakaan', 'Subjek terkait buku, penulisan, penerbitan, dan perpustakaan.'),
(3, 12, '003', 'Sistem', 'Sistem dan teori sistem, termasuk teori informasi.'),
(4, 7, '004', 'Komputer dan Teknologi Informasi', 'Teknologi komputer, perangkat keras, perangkat lunak, dan internet.'),
(5, 11, '005', 'Pemrograman dan Data', 'Bahasa pemrograman, pengolahan data, dan algoritma.'),
(6, 17, '006', 'Kecerdasan Buatan', 'Kecerdasan buatan, pengenalan pola, dan robotika.'),
(7, 13, '007', 'Jurnalistik dan Media', 'Ilmu jurnalistik, media massa, dan penyiaran.'),
(8, 13, '008', 'Perkembangan Peradaban', 'Aspek sosial, budaya, dan teknologi dalam perkembangan manusia.'),
(9, 16, '009', 'Sejarah dan Geografi Umum', 'Sejarah dunia dan geografi umum.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_format`
--

CREATE TABLE `tbl_format` (
  `id_format` bigint UNSIGNED NOT NULL,
  `kode_format` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_format`
--

INSERT INTO `tbl_format` (`id_format`, `kode_format`, `format`, `keterangan`) VALUES
(1, 'FMT001', 'Fisik', 'Buku dalam bentuk cetak'),
(2, 'FMT002', 'Ebook', 'Buku dalam bentuk elektronik'),
(3, 'FMT003', 'Jurnal', 'Publikasi ilmiah berbentuk jurnal'),
(4, 'FMT004', 'Majalah', 'Bentuk cetak majalah'),
(5, 'FMT005', 'Surat Kabar', 'Koran harian atau mingguan'),
(6, 'FMT006', 'Makalah', 'Makalah ilmiah atau tugas'),
(7, 'FMT007', 'Artikel', 'Artikel pendek atau opini'),
(8, 'FMT008', 'CD/DVD', 'File dalam bentuk CD atau DVD'),
(9, 'FMT009', 'Audio Book', 'Buku dalam bentuk audio'),
(10, 'FMT010', 'Video', 'Materi dalam bentuk video');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jenis_anggota`
--

CREATE TABLE `tbl_jenis_anggota` (
  `id_jenis_anggota` bigint UNSIGNED NOT NULL,
  `kode_jenis_anggota` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_anggota` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_pinjam` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_jenis_anggota`
--

INSERT INTO `tbl_jenis_anggota` (`id_jenis_anggota`, `kode_jenis_anggota`, `jenis_anggota`, `max_pinjam`, `keterangan`) VALUES
(1, '01', 'Administrator', '10', 'Anggota dengan hak akses penuh untuk mengelola perpustakaan.'),
(2, '02', 'Pustakawan', '5', 'Anggota yang bertanggung jawab atas pengelolaan perpustakaan.'),
(3, '03', 'Siswa', '3', 'Anggota yang merupakan siswa di sekolah ini.'),
(4, '04', 'Guru', '5', 'Anggota yang merupakan guru di sekolah ini.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_penerbit`
--

CREATE TABLE `tbl_penerbit` (
  `id_penerbit` bigint UNSIGNED NOT NULL,
  `kode_penerbit` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_penerbit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat_penerbit` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telp` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kontak` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_penerbit`
--

INSERT INTO `tbl_penerbit` (`id_penerbit`, `kode_penerbit`, `nama_penerbit`, `alamat_penerbit`, `no_telp`, `email`, `fax`, `website`, `kontak`) VALUES
(1, 'P001', 'Erlangga', 'Jl. Raya Jakarta No. 123, Jakarta', '0211234567', 'info@erlangga.co.id', '0217654321', 'https://www.erlangga.co.id', 'Bagian Publikasi'),
(2, 'P002', 'Gramedia', 'Jl. Palmerah Barat No. 29, Jakarta', '0217654321', 'contact@gramedia.com', '0218765432', 'https://www.gramedia.com', 'Layanan Pelanggan'),
(3, 'P003', 'Andi Offset', 'Jl. Sosrowijayan No. 12, Yogyakarta', '0274123456', 'cs@andioffset.co.id', '0274765432', 'https://www.andioffset.co.id', 'Admin Penerbitan'),
(4, 'P004', 'Media Edukasi', 'Jl. Kaliurang KM 7 No. 25, Sleman', '0274509876', 'info@mediaedukasi.com', '0274598765', 'https://www.mediaedukasi.com', 'Divisi Penjualan'),
(5, 'P005', 'Mizan', 'Jl. Margonda Raya No. 45, Depok', '02188990000', 'marketing@mizan.com', '02188887777', 'https://www.mizan.com', 'Tim Marketing');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengarang`
--

CREATE TABLE `tbl_pengarang` (
  `id_pengarang` bigint UNSIGNED NOT NULL,
  `kode_pengarang` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gelar_depan` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_pengarang` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gelar_belakang` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_telp` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `biografi` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_pengarang`
--

INSERT INTO `tbl_pengarang` (`id_pengarang`, `kode_pengarang`, `gelar_depan`, `nama_pengarang`, `gelar_belakang`, `no_telp`, `email`, `website`, `biografi`, `keterangan`) VALUES
(1, 'PGR001', 'Dr.', 'Casimer Von II', 'II', '+1-715-245-3580', 'kelli08@hotmail.com', 'http://gusikowski.biz/', 'Et est et odio nostrum sunt eaque enim. Eos ipsa facilis reprehenderit beatae similique voluptas ex. Debitis doloremque voluptatem dolores vitae explicabo quae ducimus est.', 'Pengarang ke 1'),
(2, 'PGR002', NULL, 'Sammie DuBuque', NULL, '+1-930-288-6377', 'ryan.amelia@hotmail.com', 'https://bashirian.net/blanditiis-eius-cum-deserunt-blanditiis-voluptas-magnam.html', 'Qui dolorem in eum. Aut eveniet illum in laboriosam. Sequi et quasi eos debitis labore neque modi. Suscipit nemo excepturi voluptas quo cupiditate consequuntur et optio.', 'Pengarang ke 2'),
(3, 'PGR003', NULL, 'Mrs. Zora Schimmel', 'II', '(952) 859-1074', 'mikayla49@hotmail.com', 'http://www.kuphal.com/maxime-sint-mollitia-sunt-sed-et', 'Et molestiae molestiae quae est. Sit voluptatem porro voluptas ea ratione mollitia porro non. Odio et illo nobis accusamus vel voluptas. Totam et qui consequuntur maxime nemo.', 'Pengarang ke 3'),
(4, 'PGR004', NULL, 'Fanny Hermiston', NULL, '(986) 326-3315', 'hane.barbara@yahoo.com', 'http://www.christiansen.com/aspernatur-et-ipsum-molestiae-tempore-beatae-est-nulla', 'Repellat commodi voluptatem omnis cupiditate non repudiandae maiores. Deleniti quaerat est ducimus alias magni autem rem eum. Consequatur optio animi voluptas nulla aut excepturi.', 'Pengarang ke 4'),
(5, 'PGR005', 'Ms.', 'Carmella Stiedemann', NULL, '+1 (440) 312-0611', 'qswift@predovic.org', 'http://doyle.com/sed-dignissimos-sunt-ut-porro', 'Aut molestias ullam aut et molestiae cum. Sapiente dolor et odit et consectetur inventore consequatur. Non iusto cum perferendis vero. Ea et corporis cumque sed quidem vitae.', 'Pengarang ke 5'),
(6, 'PGR006', 'Prof.', 'Juwan Gaylord', 'DVM', '+1 (515) 826-0638', 'ansley.heller@torp.org', 'https://www.kihn.com/sed-sed-maiores-maiores-eum', 'Atque nobis temporibus quibusdam possimus dolores. Ea itaque quia aut. Dignissimos aut dolore voluptatem dolorem temporibus. Veritatis delectus nisi maxime id saepe aut.', 'Pengarang ke 6'),
(7, 'PGR007', 'Mrs.', 'Keara Kassulke', 'Jr.', '+1-458-316-2248', 'mia16@shanahan.org', 'http://www.keebler.com/quo-nam-rerum-qui-autem-quam', 'Velit neque nihil enim. Non vero labore est sunt ut officia ea. Nam ea deleniti non culpa. Rerum incidunt delectus numquam voluptas.', 'Pengarang ke 7'),
(8, 'PGR008', NULL, 'Prof. Wilhelmine Koss', NULL, '801.525.4614', 'lizeth79@hotmail.com', 'http://cronin.com/', 'Ullam qui exercitationem qui ut sequi. Ut sint voluptatem iure illum facilis magni voluptas. Eius et sit est. Sed odit et voluptatem et aliquam quas.', 'Pengarang ke 8'),
(9, 'PGR009', NULL, 'Sydnie Langosh', NULL, '(629) 441-7920', 'ifadel@bode.com', 'http://herzog.info/voluptatum-enim-placeat-tempora-nam-et-deleniti-dignissimos-maxime.html', 'Ad quisquam illo voluptatem et impedit quis rem quibusdam. Molestiae asperiores omnis commodi laudantium sed necessitatibus voluptas.', 'Pengarang ke 9'),
(10, 'PGR010', NULL, 'Dr. Adrain Donnelly MD', 'V', '1-564-577-7001', 'vinnie99@gmail.com', 'http://www.oreilly.com/sed-suscipit-alias-officiis', 'Corrupti sed a assumenda hic et non beatae. Ut expedita eaque sed. Non aperiam qui magnam dolore non. Voluptatem quis distinctio est ut eveniet aperiam. Sit qui rerum et sunt nihil.', 'Pengarang ke 10'),
(11, 'PGR011', 'Dr.', 'Dolly Sanford', NULL, '1-574-836-5816', 'lexus.mann@walsh.info', 'http://www.wiza.biz/repellat-nam-et-ab-autem-dolores.html', 'Tempora sunt quidem dolore mollitia voluptas ea maiores fuga. Expedita et qui delectus distinctio. Culpa esse accusantium qui voluptatem nesciunt voluptatum dolorem consequatur.', 'Pengarang ke 11'),
(12, 'PGR012', NULL, 'Mossie Davis MD', NULL, '445.672.4062', 'qbayer@barton.com', 'http://ledner.com/aspernatur-dolorum-at-esse-corrupti.html', 'Et quibusdam voluptatem est ex eum maiores. Et amet dolores et enim. Repellat quia incidunt nihil molestiae.', 'Pengarang ke 12'),
(13, 'PGR013', NULL, 'Hudson Pacocha IV', NULL, '530.930.1254', 'avis24@yahoo.com', 'https://bogisich.com/dolor-praesentium-aliquid-mollitia-et-voluptatum-reiciendis-soluta.html', 'Sit quis magni quis consequuntur voluptatem et sit. Vitae rerum et sed quidem. Doloribus dolor et quasi. Qui est nemo quia hic non.', 'Pengarang ke 13'),
(14, 'PGR014', 'Prof.', 'Everardo Runolfsson', NULL, '+1-283-652-9759', 'raphael44@turcotte.com', 'http://yundt.com/doloremque-voluptatibus-nam-ipsum-dolorem', 'Soluta fuga id blanditiis magnam itaque eveniet qui. Autem cumque at et. Esse pariatur et voluptate. Neque sint aut eius ut dolores.', 'Pengarang ke 14'),
(15, 'PGR015', 'Miss', 'Keeley Kuphal', NULL, '(818) 794-4005', 'schimmel.leland@yahoo.com', 'http://www.hoppe.com/velit-tempore-omnis-ut-officia-aliquid', 'Unde sit incidunt eum provident minima quibusdam perspiciatis. Nobis quia sit maiores minus fugit. Facere eligendi praesentium blanditiis et ad. Excepturi corporis voluptas tempora et odit ratione.', 'Pengarang ke 15'),
(16, 'PGR016', 'Mr.', 'Wilhelmine Baumbach', 'PhD', '+19085772711', 'eichmann.jacquelyn@yahoo.com', 'http://www.hessel.org/temporibus-doloremque-repudiandae-est-repellendus-quo', 'Aspernatur vitae ex expedita et ratione. Enim nemo voluptatem quos sit velit. Aut libero consequatur tenetur aut aspernatur et neque. Voluptas mollitia consectetur odit voluptatum eveniet.', 'Pengarang ke 16'),
(17, 'PGR017', 'Dr.', 'Quincy Herman', NULL, '+14587131264', 'bernier.elva@feest.com', 'http://www.nienow.com/molestiae-porro-unde-velit-dolores-minima-rerum-sunt', 'In aut in odit ea nesciunt et est. Ullam libero minima rerum error aperiam.', 'Pengarang ke 17'),
(18, 'PGR018', 'Mr.', 'Winnifred Toy', NULL, '+1-724-596-0591', 'sgutkowski@hotmail.com', 'https://www.bruen.com/voluptas-sunt-qui-labore', 'Eum enim repellat tempora quaerat. Beatae et eaque ipsa. Qui nemo delectus aut ut. Asperiores voluptatibus rerum modi modi asperiores animi quos laudantium.', 'Pengarang ke 18'),
(19, 'PGR019', NULL, 'Bert Cremin', 'I', '1-283-842-6728', 'clang@bashirian.com', 'https://schaden.com/reiciendis-omnis-omnis-animi-ut-non-accusantium-est.html', 'Commodi ipsum nisi minima. Aliquid sit ab modi culpa odio deleniti. Dolorem qui illo est. Quas omnis aut numquam voluptas.', 'Pengarang ke 19'),
(20, 'PGR020', 'Prof.', 'Hal Powlowski', 'III', '+1.848.891.1405', 'jeramy.oconnell@yahoo.com', 'http://www.bergnaum.org/eveniet-animi-dolor-quos-fugit', 'Provident aut magni ea animi ratione. Alias hic qui dolorem suscipit hic ab. Enim saepe quidem excepturi distinctio facilis. Distinctio quam qui minus saepe delectus.', 'Pengarang ke 20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_perpustakaan`
--

CREATE TABLE `tbl_perpustakaan` (
  `id_perpustakaan` bigint UNSIGNED NOT NULL,
  `nama_perpustakaan` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_pustakawan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telp` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pustaka`
--

CREATE TABLE `tbl_pustaka` (
  `id_pustaka` bigint UNSIGNED NOT NULL,
  `kode_pustaka` bigint UNSIGNED NOT NULL,
  `id_ddc` bigint UNSIGNED NOT NULL,
  `id_format` bigint UNSIGNED NOT NULL,
  `id_penerbit` bigint UNSIGNED NOT NULL,
  `id_pengarang` bigint UNSIGNED NOT NULL,
  `isbn` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul_pustaka` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tahun_terbit` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keyword` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan_fisik` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan_tambahan` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abstraksi` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `harga_buku` int NOT NULL,
  `kondisi_buku` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fp` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL,
  `jml_pinjam` tinyint NOT NULL DEFAULT '0',
  `stok` tinyint NOT NULL DEFAULT '0',
  `sisa` tinyint NOT NULL DEFAULT '0',
  `denda_terlambat` int NOT NULL,
  `denda_hilang` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_pustaka`
--

INSERT INTO `tbl_pustaka` (`id_pustaka`, `kode_pustaka`, `id_ddc`, `id_format`, `id_penerbit`, `id_pengarang`, `isbn`, `judul_pustaka`, `tahun_terbit`, `keyword`, `keterangan_fisik`, `keterangan_tambahan`, `abstraksi`, `gambar`, `harga_buku`, `kondisi_buku`, `fp`, `jml_pinjam`, `stok`, `sisa`, `denda_terlambat`, `denda_hilang`) VALUES
(1, 1, 6, 1, 1, 5, '123456789X', 'The Bussiness Case of AI', '2024', 'AI', 'Tebal 300 Halaman', '-', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nec scelerisque odio. Curabitur lorem metus, porttitor at auctor ultricies, bibendum et lacus. Etiam volutpat tortor quis congue posuere. Fusce nec purus ornare erat rutrum imperdiet. Vivamus dignissim lorem sed purus faucibus, a viverra augue malesuada. Fusce malesuada purus velit, quis interdum arcu mollis congue. Morbi venenatis mi ut auctor lacinia. Vestibulum lacinia scelerisque sem sed sagittis. Mauris tincidunt libero ac imperdiet ornare. Sed auctor, ante tempus ornare pellentesque, ipsum leo lacinia magna, quis pellentesque orci diam in ex. Proin vestibulum vestibulum accumsan. Nam ipsum lacus, mattis et accumsan in, lacinia at dolor. Ut vehicula urna ut est lobortis finibus. Nunc dignissim odio vel velit eleifend, sit amet commodo lacus mollis.\n\nNunc placerat cursus risus, nec eleifend erat imperdiet a. Sed commodo imperdiet enim, nec pulvinar risus porttitor ac. Phasellus vel sollicitudin orci, non rhoncus massa. Pellentesque pretium augue nec felis molestie, ut dignissim eros facilisis. Quisque iaculis ipsum sed ipsum viverra consequat. Aliquam ut tortor purus. Praesent suscipit nulla in ultrices fringilla. Nunc lacinia elit iaculis massa luctus laoreet. Phasellus consequat turpis est, sodales scelerisque nulla dapibus fringilla. Donec interdum vitae justo id faucibus. Vivamus bibendum nunc a erat viverra varius. Vestibulum vestibulum, neque eu fringilla suscipit, diam leo efficitur lectus, in semper arcu sem vel lacus. Etiam sed felis felis. In sed metus auctor, suscipit neque ut, auctor est.', 'images/pustaka/01JHZJ01MR6CAMT5RMZYT375QM.jpg', 120000, 'Bagus', '1', 0, 10, 0, 20000, 125000),
(3, 2, 9, 1, 3, 7, '123456781X', 'Sejarah Dunia yang Disembunyikan', '2000', 'sejarah', '-', '-', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nec scelerisque odio. Curabitur lorem metus, porttitor at auctor ultricies, bibendum et lacus. Etiam volutpat tortor quis congue posuere. Fusce nec purus ornare erat rutrum imperdiet. Vivamus dignissim lorem sed purus faucibus, a viverra augue malesuada. Fusce malesuada purus velit, quis interdum arcu mollis congue. Morbi venenatis mi ut auctor lacinia. Vestibulum lacinia scelerisque sem sed sagittis. Mauris tincidunt libero ac imperdiet ornare. Sed auctor, ante tempus ornare pellentesque, ipsum leo lacinia magna, quis pellentesque orci diam in ex. Proin vestibulum vestibulum accumsan. Nam ipsum lacus, mattis et accumsan in, lacinia at dolor. Ut vehicula urna ut est lobortis finibus. Nunc dignissim odio vel velit eleifend, sit amet commodo lacus mollis.\n\nNunc placerat cursus risus, nec eleifend erat imperdiet a. Sed commodo imperdiet enim, nec pulvinar risus porttitor ac. Phasellus vel sollicitudin orci, non rhoncus massa. Pellentesque pretium augue nec felis molestie, ut dignissim eros facilisis. Quisque iaculis ipsum sed ipsum viverra consequat. Aliquam ut tortor purus. Praesent suscipit nulla in ultrices fringilla. Nunc lacinia elit iaculis massa luctus laoreet. Phasellus consequat turpis est, sodales scelerisque nulla dapibus fringilla. Donec interdum vitae justo id faucibus. Vivamus bibendum nunc a erat viverra varius. Vestibulum vestibulum, neque eu fringilla suscipit, diam leo efficitur lectus, in semper arcu sem vel lacus. Etiam sed felis felis. In sed metus auctor, suscipit neque ut, auctor est.', 'images/pustaka/01JHZJ4032K3CFNENE1ZPRQ4V0.jpg', 200000, 'Bagus', '1', 0, 12, 0, 20000, 250000),
(6, 3, 4, 1, 2, 19, '123454789X', 'Java', '2020', 'The Best in Java Concepts', 'Baik', 'Tebal 328 halaman', 'It covers all the topics of Java with explanation like object and class, this, super, instance, static, final, package, interface, abstract exception handling, applet, swing, event handling, collections, GUI, AWT, Thread, Servlet, JSP, JDBC, Look and feel, RMI, Socket programming and many more keywords and topics.\nThis book helps you to understand each and every topic of java practically. It will help you in developing software and websites because one should have sound practical knowledge. It covers all the topics which are important from the point of view of the interview, certification and examinations and no topic is left untouched.\n', 'images/pustaka/01JJYK8P7NGXN7ZNR1AGTJQFK3.jpg', 120000, 'Baik', '1', 0, 8, 0, 30000, 150000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rak`
--

CREATE TABLE `tbl_rak` (
  `id_rak` bigint UNSIGNED NOT NULL,
  `kode_rak` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rak` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_rak`
--

INSERT INTO `tbl_rak` (`id_rak`, `kode_rak`, `rak`, `keterangan`) VALUES
(1, 'RAK001', 'Rak 1', 'Keterangan rak 1'),
(2, 'RAK002', 'Rak 2', 'Keterangan rak 2'),
(3, 'RAK003', 'Rak 3', 'Keterangan rak 3'),
(4, 'RAK004', 'Rak 4', 'Keterangan rak 4'),
(5, 'RAK005', 'Rak 5', 'Keterangan rak 5'),
(6, 'RAK006', 'Rak 6', 'Keterangan rak 6'),
(7, 'RAK007', 'Rak 7', 'Keterangan rak 7'),
(8, 'RAK008', 'Rak 8', 'Keterangan rak 8'),
(9, 'RAK009', 'Rak 9', 'Keterangan rak 9'),
(10, 'RAK010', 'Rak 10', 'Keterangan rak 10'),
(11, 'RAK011', 'Rak 11', 'Keterangan rak 11'),
(12, 'RAK012', 'Rak 12', 'Keterangan rak 12'),
(13, 'RAK013', 'Rak 13', 'Keterangan rak 13'),
(14, 'RAK014', 'Rak 14', 'Keterangan rak 14'),
(15, 'RAK015', 'Rak 15', 'Keterangan rak 15'),
(16, 'RAK016', 'Rak 16', 'Keterangan rak 16'),
(17, 'RAK017', 'Rak 17', 'Keterangan rak 17'),
(18, 'RAK018', 'Rak 18', 'Keterangan rak 18'),
(19, 'RAK019', 'Rak 19', 'Keterangan rak 19'),
(20, 'RAK020', 'Rak 20', 'Keterangan rak 20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi`
--

CREATE TABLE `tbl_transaksi` (
  `id_transaksi` bigint UNSIGNED NOT NULL,
  `id_pustaka` bigint UNSIGNED NOT NULL,
  `id_anggota` bigint UNSIGNED NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `tgl_pengembalian` date DEFAULT NULL,
  `fp` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_request` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`id_transaksi`, `id_pustaka`, `id_anggota`, `tgl_pinjam`, `tgl_kembali`, `tgl_pengembalian`, `fp`, `keterangan`, `status_request`) VALUES
(1, 1, 6, '2025-01-22', '2025-01-23', NULL, '0', '-', 'approved'),
(2, 6, 6, '2025-01-31', '2025-02-07', NULL, '0', '-', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `tbl_anggota`
--
ALTER TABLE `tbl_anggota`
  ADD PRIMARY KEY (`id_anggota`),
  ADD UNIQUE KEY `tbl_anggota_kode_anggota_unique` (`kode_anggota`),
  ADD UNIQUE KEY `tbl_anggota_nama_anggota_unique` (`nama_anggota`),
  ADD UNIQUE KEY `tbl_anggota_username_unique` (`username`),
  ADD KEY `tbl_anggota_id_jenis_anggota_foreign` (`id_jenis_anggota`);

--
-- Indexes for table `tbl_ddc`
--
ALTER TABLE `tbl_ddc`
  ADD PRIMARY KEY (`id_ddc`),
  ADD UNIQUE KEY `tbl_ddc_kode_ddc_unique` (`kode_ddc`),
  ADD KEY `tbl_ddc_id_rak_foreign` (`id_rak`);

--
-- Indexes for table `tbl_format`
--
ALTER TABLE `tbl_format`
  ADD PRIMARY KEY (`id_format`),
  ADD UNIQUE KEY `tbl_format_kode_format_unique` (`kode_format`);

--
-- Indexes for table `tbl_jenis_anggota`
--
ALTER TABLE `tbl_jenis_anggota`
  ADD PRIMARY KEY (`id_jenis_anggota`),
  ADD UNIQUE KEY `tbl_jenis_anggota_kode_jenis_anggota_unique` (`kode_jenis_anggota`);

--
-- Indexes for table `tbl_penerbit`
--
ALTER TABLE `tbl_penerbit`
  ADD PRIMARY KEY (`id_penerbit`),
  ADD UNIQUE KEY `tbl_penerbit_kode_penerbit_unique` (`kode_penerbit`),
  ADD UNIQUE KEY `tbl_penerbit_nama_penerbit_unique` (`nama_penerbit`);

--
-- Indexes for table `tbl_pengarang`
--
ALTER TABLE `tbl_pengarang`
  ADD PRIMARY KEY (`id_pengarang`),
  ADD UNIQUE KEY `tbl_pengarang_kode_pengarang_unique` (`kode_pengarang`),
  ADD UNIQUE KEY `tbl_pengarang_nama_pengarang_unique` (`nama_pengarang`);

--
-- Indexes for table `tbl_perpustakaan`
--
ALTER TABLE `tbl_perpustakaan`
  ADD PRIMARY KEY (`id_perpustakaan`),
  ADD UNIQUE KEY `tbl_perpustakaan_nama_perpustakaan_unique` (`nama_perpustakaan`),
  ADD UNIQUE KEY `tbl_perpustakaan_email_unique` (`email`);

--
-- Indexes for table `tbl_pustaka`
--
ALTER TABLE `tbl_pustaka`
  ADD PRIMARY KEY (`id_pustaka`),
  ADD UNIQUE KEY `tbl_pustaka_kode_pustaka_unique` (`kode_pustaka`),
  ADD UNIQUE KEY `tbl_pustaka_isbn_unique` (`isbn`),
  ADD KEY `tbl_pustaka_id_ddc_foreign` (`id_ddc`),
  ADD KEY `tbl_pustaka_id_format_foreign` (`id_format`),
  ADD KEY `tbl_pustaka_id_penerbit_foreign` (`id_penerbit`),
  ADD KEY `tbl_pustaka_id_pengarang_foreign` (`id_pengarang`);

--
-- Indexes for table `tbl_rak`
--
ALTER TABLE `tbl_rak`
  ADD PRIMARY KEY (`id_rak`),
  ADD UNIQUE KEY `tbl_rak_kode_rak_unique` (`kode_rak`),
  ADD UNIQUE KEY `tbl_rak_rak_unique` (`rak`);

--
-- Indexes for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `tbl_transaksi_id_pustaka_foreign` (`id_pustaka`),
  ADD KEY `tbl_transaksi_id_anggota_foreign` (`id_anggota`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_anggota`
--
ALTER TABLE `tbl_anggota`
  MODIFY `id_anggota` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_ddc`
--
ALTER TABLE `tbl_ddc`
  MODIFY `id_ddc` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_format`
--
ALTER TABLE `tbl_format`
  MODIFY `id_format` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_jenis_anggota`
--
ALTER TABLE `tbl_jenis_anggota`
  MODIFY `id_jenis_anggota` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_penerbit`
--
ALTER TABLE `tbl_penerbit`
  MODIFY `id_penerbit` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_pengarang`
--
ALTER TABLE `tbl_pengarang`
  MODIFY `id_pengarang` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_perpustakaan`
--
ALTER TABLE `tbl_perpustakaan`
  MODIFY `id_perpustakaan` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_pustaka`
--
ALTER TABLE `tbl_pustaka`
  MODIFY `id_pustaka` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_rak`
--
ALTER TABLE `tbl_rak`
  MODIFY `id_rak` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  MODIFY `id_transaksi` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_anggota`
--
ALTER TABLE `tbl_anggota`
  ADD CONSTRAINT `tbl_anggota_id_jenis_anggota_foreign` FOREIGN KEY (`id_jenis_anggota`) REFERENCES `tbl_jenis_anggota` (`id_jenis_anggota`);

--
-- Constraints for table `tbl_ddc`
--
ALTER TABLE `tbl_ddc`
  ADD CONSTRAINT `tbl_ddc_id_rak_foreign` FOREIGN KEY (`id_rak`) REFERENCES `tbl_rak` (`id_rak`);

--
-- Constraints for table `tbl_pustaka`
--
ALTER TABLE `tbl_pustaka`
  ADD CONSTRAINT `tbl_pustaka_id_ddc_foreign` FOREIGN KEY (`id_ddc`) REFERENCES `tbl_ddc` (`id_ddc`),
  ADD CONSTRAINT `tbl_pustaka_id_format_foreign` FOREIGN KEY (`id_format`) REFERENCES `tbl_format` (`id_format`),
  ADD CONSTRAINT `tbl_pustaka_id_penerbit_foreign` FOREIGN KEY (`id_penerbit`) REFERENCES `tbl_penerbit` (`id_penerbit`),
  ADD CONSTRAINT `tbl_pustaka_id_pengarang_foreign` FOREIGN KEY (`id_pengarang`) REFERENCES `tbl_pengarang` (`id_pengarang`);

--
-- Constraints for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  ADD CONSTRAINT `tbl_transaksi_id_anggota_foreign` FOREIGN KEY (`id_anggota`) REFERENCES `tbl_anggota` (`id_anggota`),
  ADD CONSTRAINT `tbl_transaksi_id_pustaka_foreign` FOREIGN KEY (`id_pustaka`) REFERENCES `tbl_pustaka` (`id_pustaka`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
